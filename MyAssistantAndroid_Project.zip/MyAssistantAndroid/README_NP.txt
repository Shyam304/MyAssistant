MY ASSISTANT - Android App source project

यो Android Studio मा खोल्न मिल्ने project हो।

सुविधाहरू:
- दैनिक मिति र घडी देखाउँछ
- Task थप्न, पूरा भएको चिन्ह लगाउन र हटाउन मिल्छ
- Task हरू फोनमै सुरक्षित रहन्छन् (app बन्द गरेपछि पनि)

APK बनाउन:
1. कम्प्युटरमा Android Studio स्थापना गर्नुहोस्।
2. Android Studio खोलेर 'Open' छान्नुहोस्।
3. यो ZIP extract गरेर MyAssistantAndroid folder छान्नुहोस्।
4. Gradle sync पूरा हुन दिनुहोस्।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) छान्नुहोस्।
6. APK app/build/outputs/apk/debug/ मा भेटिन्छ।

Package: com.example.myassistant
Minimum Android: Android 6.0 (API 23)
