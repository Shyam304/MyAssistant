package com.example.myassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val tasks = mutableListOf<Pair<String, Boolean>>()
    private lateinit var list: LinearLayout
    private lateinit var progress: TextView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("tasks", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadTasks()
        buildScreen()
        renderTasks()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(Color.rgb(248, 250, 252))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val appTitle = TextView(this).apply {
            text = "MY ASSISTANT"
            textSize = 13f
            setTextColor(Color.rgb(37, 99, 235))
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(appTitle)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(Color.rgb(23, 37, 84))
        }
        val welcome = TextView(this).apply {
            text = "Your Daily Planner"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
            textSize = 14f
            setTextColor(Color.rgb(191, 219, 254))
            setPadding(0, dp(8), 0, 0)
        }
        hero.addView(welcome)
        hero.addView(date)
        val clock = TextView(this).apply {
            text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
        }
        hero.addView(clock)
        val heroParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(16); bottomMargin = dp(24)
        }
        content.addView(hero, heroParams)

        val heading = TextView(this).apply {
            text = "Today's tasks"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(15, 23, 42))
        }
        content.addView(heading)
        progress = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(5), 0, dp(12))
        }
        content.addView(progress)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        input = EditText(this).apply {
            hint = "Enter a new task"
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        val add = Button(this).apply {
            text = "ADD TASK"
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    tasks.add(value to false)
                    input.setText("")
                    saveTasks()
                    renderTasks()
                } else {
                    Toast.makeText(this@MainActivity, "Please enter a task", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
            addView(add, LinearLayout.LayoutParams(-1, -2))
        }
        content.addView(addRow)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderTasks() {
        list.removeAllViews()
        val completed = tasks.count { it.second }
        progress.text = "$completed of ${tasks.size} completed"
        if (tasks.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No tasks yet. Add your first task below."
                textSize = 14f
                setTextColor(Color.GRAY)
                setPadding(0, dp(16), 0, dp(16))
            }
            list.addView(empty)
        }
        tasks.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(4), dp(6))
                setBackgroundColor(Color.WHITE)
            }
            val check = CheckBox(this).apply {
                text = item.first
                textSize = 15f
                isChecked = item.second
                setTextColor(if (item.second) Color.GRAY else Color.rgb(30, 41, 59))
                setOnCheckedChangeListener { _, checked ->
                    if (index < tasks.size) {
                        tasks[index] = tasks[index].first to checked
                        saveTasks()
                        renderTasks()
                    }
                }
            }
            val delete = TextView(this).apply {
                text = "✕"
                textSize = 20f
                setTextColor(Color.rgb(220, 38, 38))
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener {
                    if (index < tasks.size) {
                        tasks.removeAt(index)
                        saveTasks()
                        renderTasks()
                    }
                }
            }
            row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(delete)
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
            list.addView(row, params)
        }
    }

    private fun saveTasks() {
        val array = JSONArray()
        tasks.forEach { (name, done) ->
            array.put(JSONObject().put("name", name).put("done", done))
        }
        prefs.edit().putString("items", array.toString()).apply()
    }

    private fun loadTasks() {
        val raw = prefs.getString("items", null)
        if (raw != null) {
            try {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    tasks.add(obj.getString("name") to obj.getBoolean("done"))
                }
            } catch (_: Exception) { tasks.clear() }
        } else {
            tasks.add("Wake up early" to false)
            tasks.add("Read the Bible" to false)
            tasks.add("Exercise" to false)
            tasks.add("Study English" to false)
        }
    }
}
